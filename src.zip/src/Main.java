import com.data.globant_final_work.java.CourseMU;
import com.data.globant_final_work.java.MetropolitanUniversityMU;

import java.util.ArrayList;
import java.util.List;
import com.data.globant_final_work.java.StudentMU;
import com.data.globant_final_work.java.typeTeacher.FullTimeTeacherMU;
import com.data.globant_final_work.java.typeTeacher.PartTimeTeacherMU;
import com.data.globant_final_work.java.typeTeacher.TeacherMU;
import com.uiMenu.globant_final_work.java.UIUniversityMenu;



public class Main {


    public static void main(String[] args) {
        System.out.println("*********************************************************************************");
        System.out.println("Welcome to the Metropolitan University platform - Chemical Engineering department");
        System.out.println("*********************************************************************************");

        MetropolitanUniversityMU metropolitanUniversityMU = initializeUniversity();

        UIUniversityMenu universityMenu = new UIUniversityMenu();
        universityMenu.showMainMenu(metropolitanUniversityMU);
    }

    public static MetropolitanUniversityMU initializeUniversity() {

        MetropolitanUniversityMU metropolitanUniversityMU = new MetropolitanUniversityMU();


        // Teacher list
        TeacherMU teacher1 = new FullTimeTeacherMU("Felipe Bustamante", 1200000, 10);
        TeacherMU teacher2 = new FullTimeTeacherMU("Heberto Tapias", 1200000, 6);
        TeacherMU teacher3 = new PartTimeTeacherMU("Rosario Caicedo", 1200000, 20);
        TeacherMU teacher4 = new PartTimeTeacherMU("Mauricio Sanchez", 1200000, 30);


        metropolitanUniversityMU.getTeachersMU().add(teacher1);
        metropolitanUniversityMU.getTeachersMU().add(teacher2);
        metropolitanUniversityMU.getTeachersMU().add(teacher3);
        metropolitanUniversityMU.getTeachersMU().add(teacher4);

        // Student list


        StudentMU student1 = new StudentMU( "Marisol Jaramillo", 19);
        StudentMU student2 = new StudentMU("Camilo Fernandez", 18);
        StudentMU student3 = new StudentMU("Paulina Torres", 20);
        StudentMU student4 = new StudentMU("Walter Garzón", 19);
        StudentMU student5 = new StudentMU("Natalia Rendón", 21);
        StudentMU student6 = new StudentMU("Sebastian Cardona", 22);

        metropolitanUniversityMU.getStudentsMU().add(student1);
        metropolitanUniversityMU.getStudentsMU().add(student2);
        metropolitanUniversityMU.getStudentsMU().add(student3);
        metropolitanUniversityMU.getStudentsMU().add(student4);
        metropolitanUniversityMU.getStudentsMU().add(student5);
        metropolitanUniversityMU.getStudentsMU().add(student6);

        // Array list students
        List<StudentMU> studentsCourse1= new ArrayList<>();
        studentsCourse1.add(student1);
        studentsCourse1.add(student3);
        studentsCourse1.add(student6);

        List<StudentMU> studentsCourse2= new ArrayList<>();
        studentsCourse2.add(student2);
        studentsCourse2.add(student3);
        studentsCourse2.add(student4);

        List<StudentMU> studentsCourse3= new ArrayList<>();
        studentsCourse3.add(student1);
        studentsCourse3.add(student4);
        studentsCourse3.add(student6);

        List<StudentMU> studentsCourse4= new ArrayList<>();
        studentsCourse4.add(student2);
        studentsCourse4.add(student5);
        studentsCourse4.add(student6);

        // Courses list


        CourseMU course1 = new CourseMU("Thermodynamics", 101, teacher1, studentsCourse1);
        CourseMU course2 = new CourseMU("Process Design", 102, teacher2, studentsCourse2);
        CourseMU course3 = new CourseMU("Physical-chemistry", 103, teacher3,studentsCourse3);
        CourseMU course4 = new CourseMU("Control and Instrumentation", 104, teacher4,studentsCourse4);

        metropolitanUniversityMU.getCoursesMU().add(course1);
        metropolitanUniversityMU.getCoursesMU().add(course2);
        metropolitanUniversityMU.getCoursesMU().add(course3);
        metropolitanUniversityMU.getCoursesMU().add(course4);

        return metropolitanUniversityMU;
    }

}
