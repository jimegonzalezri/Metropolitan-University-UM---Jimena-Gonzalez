package com.data.globant_final_work.java.typeTeacher;

public class PartTimeTeacherMU extends TeacherMU{


    // Atributes
    private float laborHoursPerWeek;

    // Constructor

    public PartTimeTeacherMU( String name, double baseSalary,float laborHoursPerWeek){
        super(name,baseSalary);
        this.laborHoursPerWeek=laborHoursPerWeek;
    }

        // Getter y Setter

    public double getLaborHoursPerWeek() {
        return laborHoursPerWeek;
    }

    public void setLaborHoursPerWeek(float laborHoursPerWeek) {
        this.laborHoursPerWeek = laborHoursPerWeek;
    }


    @Override
    public double calculateSalary() {
        double salary;
        salary = super.baseSalary*this.laborHoursPerWeek*0.0052*4;
        return salary;
    }

    @Override
    public String toString() {
        return super.toString()+ "\n   Type of teacher: PartTimeTeacher" +
                "\n   Labor Hours per week: " + this.laborHoursPerWeek +
                " \n   The salary of " + getName() + " is:  COP $ ";
    };
}
