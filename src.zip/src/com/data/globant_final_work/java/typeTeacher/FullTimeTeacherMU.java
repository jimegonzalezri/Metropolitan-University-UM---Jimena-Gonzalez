package com.data.globant_final_work.java.typeTeacher;



public class FullTimeTeacherMU extends TeacherMU {

    private float yearsOfExperience;


    public FullTimeTeacherMU(String name, double baseSalary, float yearsOfExperience) {
        super(name, baseSalary);
        this.yearsOfExperience = yearsOfExperience;
    }


    // Getter y Setter


    public float getYearsOfExperience() {
        return yearsOfExperience;
    }

    public void setYearsOfExperience(float yearsOfExperience) {
        this.yearsOfExperience = yearsOfExperience;
    }


    @Override
    public double calculateSalary() {

        double salary;
        salary = super.baseSalary * (1.1 * this.yearsOfExperience);
        return (salary);

    }

    @Override
    public String toString() {
        return super.toString()+ "\n   Type of teacher: FullTimeTeacher" +
                "\n   Years Of Experience: " + yearsOfExperience +
                " \n   The salary of " + getName() + " is:  COP $ " ;
                };

}