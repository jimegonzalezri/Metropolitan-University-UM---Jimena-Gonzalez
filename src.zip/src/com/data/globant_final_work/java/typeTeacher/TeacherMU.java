package com.data.globant_final_work.java.typeTeacher;

import com.data.globant_final_work.java.Person;


public abstract class TeacherMU extends Person {

    // Attributes
    private double salary;
    protected double baseSalary;

    // Constructor

    public TeacherMU(String name, double baseSalary) {
        super(name);
        this.baseSalary = baseSalary;
    }


    // Getter y Setter


    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }


    public abstract double calculateSalary();

    

    @Override
    public String toString() {
        return super.toString() + "  "+ "\n   Base Salary: COP $ " + baseSalary+ "  ";
    }
}


