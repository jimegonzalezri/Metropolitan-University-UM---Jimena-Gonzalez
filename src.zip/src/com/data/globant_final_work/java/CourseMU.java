package com.data.globant_final_work.java;

import com.data.globant_final_work.java.typeTeacher.TeacherMU;
import java.util.List;

public class CourseMU {


    private String nameCourse;
    private int classroomCourseNumber;
    private List<StudentMU> studentsCourse;
    private TeacherMU teacherMU;



    public CourseMU(String nameCourse, int classroomCourseNumber, TeacherMU teacherMU, List<StudentMU>studentsCourse) {
        this.nameCourse = nameCourse;
        this.classroomCourseNumber = classroomCourseNumber;
        this.teacherMU=teacherMU;
        this.studentsCourse = studentsCourse;
    }




    public String getNameCourse() {
        return nameCourse;
    }

    public void setNameCourse(String nameCourse) {
        this.nameCourse = nameCourse;
    }

    public int getClassroomCourseNumber() {
        return classroomCourseNumber;
    }

    public void setClassroomCourseNumber(int classroomCourseNumber) {
        this.classroomCourseNumber = classroomCourseNumber;
    }

    public List<StudentMU> getStudentsCourse() {
        return studentsCourse;
    }

    public void setStudentsCourse(List<StudentMU> studentsCourse) {
        this.studentsCourse = studentsCourse;
    }

    public TeacherMU getTeacherMU() {
        return teacherMU;
    }

    public void setTeacherMU(TeacherMU teacherMU) {
        this.teacherMU = teacherMU;
    }


    public void showCourseDetails(){
        System.out.println("Name of course: " + nameCourse +
                "\nClassroom N°: " + classroomCourseNumber +
                "\nTeacher Name: " + teacherMU.getName() +
                "\nStudents Course:  ");
        showStudentsPerCourse();
    }

    public void showCourseWithNoStudents(){
        System.out.println("Name of course: " + nameCourse +
                "\nClassroom N°: " + classroomCourseNumber +
                "\nTeacher Name: " + teacherMU.getName() );
    }


    public void showStudentsPerCourse(){
        for (int i = 0; i < studentsCourse.size(); i++) {
             System.out.println((i + 1) + ". " + "ID Student: " +  studentsCourse.get(i).getIdStudent() + ", Name: "+  studentsCourse.get(i).getName() +
                     ", Age Student: " + studentsCourse.get(i).getAgeStudent() );
    }
        System.out.println("---------------------------");
}

    @Override
    public String toString() {
        return   "Name of course: " + nameCourse;

    }


}
