package com.data.globant_final_work.java;

import com.data.globant_final_work.java.typeTeacher.FullTimeTeacherMU;
import com.data.globant_final_work.java.typeTeacher.PartTimeTeacherMU;
import com.data.globant_final_work.java.typeTeacher.TeacherMU;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class MetropolitanUniversityMU {


    private List<StudentMU> studentsMU;
    private List<TeacherMU> teachersMU;
    private List<CourseMU> coursesMU;

    public MetropolitanUniversityMU() {
        this.studentsMU = new ArrayList<>();
        this.teachersMU = new ArrayList<>();
        this.coursesMU = new ArrayList<>();
    }



    public List<StudentMU> getStudentsMU() {
        return studentsMU;
    }

    public void setStudentsMU(List<StudentMU> studentsMU) {
        this.studentsMU = studentsMU;
    }

    public List<TeacherMU> getTeachersMU() {
        return teachersMU;
    }

    public void setTeachersMU(List<TeacherMU> teachersMU) {
        this.teachersMU = teachersMU;
    }

    public List<CourseMU> getCoursesMU() {
        return coursesMU;
    }

    public void setCoursesMU(List<CourseMU> coursesMU) {
        this.coursesMU = coursesMU;
    }




    public void showStudentsUniversity() {
        for (int i = 0; i < studentsMU.size(); i++) {
            System.out.println("ID Student: " + studentsMU.get(i).getIdStudent() + ", Name Student: " + studentsMU.get(i).getName() +
                    ", Age Student: " + studentsMU.get(i).getAgeStudent());
        }
    }



    public void listTeachers() {
        for (int i = 0; i < teachersMU.size(); i++) {
            DecimalFormat df = new DecimalFormat("#");
            df.setMaximumFractionDigits(2);
            System.out.println((i + 1) + ". " + teachersMU.get(i).toString() + (df.format(teachersMU.get(i).calculateSalary())));
        }
        System.out.println("-------END OF THE LIST----------");
        System.out.println("\n");
    }


    public void listCoursesNames() {
        for (int i = 0; i < coursesMU.size(); i++) {
            System.out.println((i + 1) + ". " + coursesMU.get(i).toString());
        }
    }

    public void listCourseNamesAndClassroom() {
        for (int i = 0; i < coursesMU.size(); i++) {
            System.out.println((i + 1) + ". " + coursesMU.get(i).getNameCourse() + ", Classroom: " + coursesMU.get(i).getClassroomCourseNumber());
        }
    }



    public void addNewStudent(String nameNewStudent, int ageStudent) {
        StudentMU newStudent = new StudentMU(nameNewStudent, ageStudent);
        studentsMU.add(newStudent);
        System.out.println("Id Student: " + newStudent.getIdStudent() + "\nStudent: " + nameNewStudent + "\nAge: " + ageStudent + " years");
        System.out.println("Student successfully added !! :)");
    }



    public void createNewCourse(String nameNewCourse, int newClassroom, TeacherMU newTeacher, List<StudentMU>newStudentMenu){
        CourseMU newCourseMU = new CourseMU(nameNewCourse, newClassroom, newTeacher, newStudentMenu);
        coursesMU.add(newCourseMU);
    }



    public void addNewStudentToCourse(StudentMU studentMU, CourseMU courseMU){
                courseMU.getStudentsCourse().add(studentMU);
    }

    public void createNewFullTimeTeacher(String nameNewTeacher, double baseSalaryNewTeacher,float yearsOfExperienceNewTeacher){
        TeacherMU newFullTimeTeacher = new FullTimeTeacherMU(nameNewTeacher, baseSalaryNewTeacher, yearsOfExperienceNewTeacher);
        teachersMU.add(newFullTimeTeacher);
        System.out.println("Name new teacher: " + nameNewTeacher + ", Base Salary: " + baseSalaryNewTeacher +
                            ", Years of Experience: " + yearsOfExperienceNewTeacher);
        System.out.println("Teacher successfully added !! :)");
    }

    public void createNewPartTimeTeacher(String nameNewTeacher, double baseSalaryNewTeacher,float LaborHoursPerWeekNewTeacher){
        TeacherMU newPartTimeTeacher = new PartTimeTeacherMU(nameNewTeacher, baseSalaryNewTeacher, LaborHoursPerWeekNewTeacher);
        teachersMU.add(newPartTimeTeacher);
        System.out.println("Name new teacher: " + nameNewTeacher + ", Base Salary: " + baseSalaryNewTeacher +
                ", Years of Experience: " + LaborHoursPerWeekNewTeacher);
        System.out.println("Teacher successfully added!! :)");
    }

    public void setCoursesPerStudent(int IDStudentSelected){
        System.out.println("Courses student: " +  studentsMU.get(IDStudentSelected).getName() + " :");
        System.out.println("--------------------------");
        studentsMU.get(IDStudentSelected);
        for (int i = 0; i < coursesMU.size(); i++) {
            for (int j = 0; j < coursesMU.get(i).getStudentsCourse().size(); j++) {
                if(IDStudentSelected==coursesMU.get(i).getStudentsCourse().get(j).getIdStudent()){
                    coursesMU.get(i).showCourseWithNoStudents();
                    System.out.println("---------------------------");
                }
            }
        }


    }

}


