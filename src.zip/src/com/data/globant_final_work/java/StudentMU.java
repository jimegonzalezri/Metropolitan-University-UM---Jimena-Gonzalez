package com.data.globant_final_work.java;

public class StudentMU extends Person {


    public static int id;
    private int ageStudent;
    private int idStudent;




    public StudentMU(String name, int ageStudent) {
        super(name);
        this.ageStudent = ageStudent;
        this.idStudent=1+StudentMU.id++;
    }



    public int getIdStudent() {
        return idStudent;
    }

    public void setIdStudent(int idStudent) {
        this.idStudent = idStudent;
    }

    public int getAgeStudent() {
        return ageStudent;
    }

    public void setAgeStudent(int ageStudent) {
        this.ageStudent = ageStudent;
    }


    @Override
    public String toString() {
        return  super.toString() + "StudentMU{" +
                "idStudent=" + idStudent +
                ", ageStudent=" + ageStudent +
                '}';
    }
}
