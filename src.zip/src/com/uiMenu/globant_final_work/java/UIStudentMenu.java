package com.uiMenu.globant_final_work.java;


import com.data.globant_final_work.java.MetropolitanUniversityMU;
import java.util.Scanner;

public class UIStudentMenu {

    public void askForStudent(MetropolitanUniversityMU metropolitanUniversityMU){
        int response = 0;
        do{
            Scanner sc = new Scanner(System.in);
            System.out.println("\n");
        System.out.println("-------------Create new student-------------:");
        System.out.println("Please enter the following data information: ");
        System.out.println("Complete name of the Student:");
        String nameNewStudent = sc.nextLine();
        System.out.println("Indicate age of student in years");
        int ageStudent = sc.nextInt();
        metropolitanUniversityMU.addNewStudent(nameNewStudent,ageStudent);
        }
        while(response!=0);
    }

    public void askForAddNewStudentToCourse(MetropolitanUniversityMU metropolitanUniversityMU) {
        int response = 0;
        do {
            System.out.println("Please select the course you want to add the new student");
            metropolitanUniversityMU.listCoursesNames();
            Scanner sc = new Scanner(System.in);
            int courseSelection = sc.nextInt();
            int courseSelectionMatch = courseSelection - 1;
            for (int i = 0; i < metropolitanUniversityMU.getCoursesMU().size(); i++) {
                metropolitanUniversityMU.getCoursesMU().get(courseSelectionMatch).getNameCourse();
            }
            System.out.println("The course you selected is " + metropolitanUniversityMU.getCoursesMU().get(courseSelectionMatch).getNameCourse());
            System.out.println("Is it correct? \n1. Correct \n2. Change course");
            Scanner cs = new Scanner(System.in);
            int responseCourse = cs.nextInt();
                if (responseCourse == 1) {
                    metropolitanUniversityMU.addNewStudentToCourse(
                            metropolitanUniversityMU.getStudentsMU().get(metropolitanUniversityMU.getStudentsMU().size()-1),
                            metropolitanUniversityMU.getCoursesMU().get(courseSelectionMatch));
                            System.out.println("Student successfully added to course: "+ metropolitanUniversityMU.getCoursesMU().get(courseSelectionMatch).getNameCourse());
                            System.out.println("\n");

                } else if (responseCourse == 2) {
                    askForAddNewStudentToCourse(metropolitanUniversityMU);
                }

            System.out.println("¿ do you want to add another  student to another course? \n1. Yes \n2. No, take me to the main Menu");
            int studentSelection= sc.nextInt();
            if (studentSelection == 2) {
                    UIUniversityMenu mainMenu = new UIUniversityMenu();
                    mainMenu.showMainMenu(metropolitanUniversityMU);
            } else if (studentSelection == 1) {
                 askForStudent(metropolitanUniversityMU);
                askForAddNewStudentToCourse(metropolitanUniversityMU);

            }
        }while (response != 0);

    }

    public void AskForStudentToShowCourses(MetropolitanUniversityMU metropolitanUniversityMU){
        int response = 0;
        do{
            Scanner sc = new Scanner(System.in);
            System.out.println("-------------List of current students-------------:");
            metropolitanUniversityMU.showStudentsUniversity();
            System.out.println("Please select the ID of the student you want to see: ");
            int IDStudentSelectedInitial= sc.nextInt();
            int IDStudentSelected = IDStudentSelectedInitial-1;
            System.out.println("----List of Courses --- ");
            metropolitanUniversityMU.setCoursesPerStudent(IDStudentSelected);
            System.out.println("Do you want to see another student? \n1. Yes \n2. No, take me to the main Menu");
            int studentSelection= sc.nextInt();
            if (studentSelection == 2) {

            } else if (studentSelection == 1) {
                AskForStudentToShowCourses(metropolitanUniversityMU);
            }
        }
        while(response!=0);
    }

}




