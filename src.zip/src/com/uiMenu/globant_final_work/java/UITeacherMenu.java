package com.uiMenu.globant_final_work.java;

import com.data.globant_final_work.java.MetropolitanUniversityMU;

import java.util.Scanner;

public class UITeacherMenu {

    public void showTeachersInfo(MetropolitanUniversityMU metropolitanUniversityMU){
        metropolitanUniversityMU.listTeachers();
        Scanner sc = new Scanner(System.in);
        System.out.println("What do you want to do next?");
        System.out.println("Please select:  \n1. Return to main Menu \n2. Exit");
        int selection= sc.nextInt();
        if(selection==2){
            System.out.println("Thanks for your visit");
        } else if (selection==1){
            UIUniversityMenu uiUniversityMenu = new UIUniversityMenu();
            uiUniversityMenu.showMainMenu(metropolitanUniversityMU);
        }

    }

    public void AskForTeacherInfo(MetropolitanUniversityMU metropolitanUniversityMU){
        int response = 0;
        do {
            Scanner sc = new Scanner(System.in);
            System.out.println("Please insert the following information for the new teacher");
            System.out.println("Please select if new teacher is  \n1. Full Time Teacher \n2. Part time teacher");
            int teacherSelection = sc.nextInt();
            if (teacherSelection == 1) {
                Scanner th = new Scanner(System.in);
                System.out.println("Please insert name of new teacher");
                String nameNewTeacher = th.nextLine();
                System.out.println("Please insert base Salary in COP $");
                Double baseSalaryNewTeacher = th.nextDouble();
                System.out.println("Please insert years of experience");
                int yearsOfExperienceNewTeacher = th.nextInt();
                metropolitanUniversityMU.createNewFullTimeTeacher(nameNewTeacher, baseSalaryNewTeacher, yearsOfExperienceNewTeacher);
            } else if (teacherSelection == 2) {
                Scanner th = new Scanner(System.in);
                System.out.println("Please insert name of new teacher");
                String nameNewTeacher = th.nextLine();
                System.out.println("Please insert base Salary in COP $");
                Double baseSalaryNewTeacher = th.nextDouble();
                System.out.println("Please insert Labor hours per week");
                int LaborHoursPerWeekNewTeacher = th.nextInt();
                metropolitanUniversityMU.createNewPartTimeTeacher(nameNewTeacher, baseSalaryNewTeacher, LaborHoursPerWeekNewTeacher);
            }
        }while(response!=0);
        }
    }


