package com.uiMenu.globant_final_work.java;


import com.data.globant_final_work.java.MetropolitanUniversityMU;
import java.util.Scanner;

public class UIUniversityMenu {


        // Methods
        public void showMainMenu(MetropolitanUniversityMU metropolitanUniversityMU) {
                System.out.println("-----MAIN MENU:------");
                System.out.println("Please select an option:");

                int response = 0;
                do {
                        System.out.println("1. See list of teachers and their data");
                        System.out.println("2. See list of courses and their information");
                        System.out.println("3. Create new student and register to a course");
                        System.out.println("4. Create new course and assign teacher and students");
                        System.out.println("5. See list of courses per student ");
                        System.out.println("6. Exit");

                        Scanner sc = new Scanner(System.in);
                        response = sc.nextInt();

                        switch (response) {
                                case 1:
                                        System.out.println("****************************************");
                                        System.out.println("List of teachers Metropolitan University");
                                        System.out.println("****************************************");
                                        UITeacherMenu teachersMenu = new UITeacherMenu();
                                        teachersMenu.showTeachersInfo(metropolitanUniversityMU);
                                        response = 0;
                                        break;
                                case 2:
                                        System.out.println("****************************************");
                                        System.out.println("List of courses Metropolitan University");
                                        System.out.println("****************************************");
                                        metropolitanUniversityMU.listCoursesNames();
                                        UICoursesMenu coursesMenu = new UICoursesMenu();
                                        coursesMenu.AskForCourseInformationToSee(metropolitanUniversityMU);
                                        showMainMenu( metropolitanUniversityMU);
                                        response = 0;
                                        break;
                                case 3:
                                        System.out.println("****************************************");
                                        System.out.println("Create new student and register to new course");
                                        System.out.println("****************************************");
                                        UIStudentMenu studentMenu = new UIStudentMenu();
                                        studentMenu.askForStudent(metropolitanUniversityMU);
                                        studentMenu.askForAddNewStudentToCourse(metropolitanUniversityMU);
                                        showMainMenu( metropolitanUniversityMU);
                                        response=0;
                                        break;
                                case 4:
                                        System.out.println("****************************************");
                                        System.out.println("Create new course and assign teacher and students");
                                        System.out.println("****************************************");
                                        UICoursesMenu newCourseMenu= new UICoursesMenu();
                                        newCourseMenu.AskForNewCourse(metropolitanUniversityMU);
                                        showMainMenu( metropolitanUniversityMU);
                                        response=0;
                                        break;
                                case 5:
                                       System.out.println("****************************************");
                                       System.out.println("See list of courses per Student");
                                       System.out.println("****************************************");
                                       UIStudentMenu newStudentCourses = new UIStudentMenu();
                                       newStudentCourses.AskForStudentToShowCourses(metropolitanUniversityMU);
                                       showMainMenu(metropolitanUniversityMU);
                                       response=0;
                                       break;
                                case 6:
                                        System.out.println("Thank you for your visit");
                                        response=0;
                                        break;
                                default:
                                        System.out.println("ALERT!!! Incorrect Selection!. Please select a correct option");
                                        showMainMenu(metropolitanUniversityMU);
                        }
                }
                while (response != 0);

        }


}


