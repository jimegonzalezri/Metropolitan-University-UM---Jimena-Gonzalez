package com.uiMenu.globant_final_work.java;


import com.data.globant_final_work.java.MetropolitanUniversityMU;
import com.data.globant_final_work.java.StudentMU;
import java.util.ArrayList;
import java.util.Scanner;

public class UICoursesMenu {

    public void AskForCourseInformationToSee(MetropolitanUniversityMU metropolitanUniversityMU){
        int response =0;
        do{
        System.out.println("+++++++++++++++++++++++++++++++");
        System.out.println("For details, please select the number of the course you want to see:");
        System.out.println("++++++++++++++++++++++++++++++++");
        Scanner sc = new Scanner(System.in);
        int selection = sc.nextInt();
        int selectionMatch = selection-1;
        for (int i = 0; i < metropolitanUniversityMU.getCoursesMU().size()-1; i++) {
            metropolitanUniversityMU.getCoursesMU().get(selectionMatch).showCourseDetails();
            break;
            }

        System.out.println("¿ do you want to see another course? \n1. Yes \n2. No, take me to the main Menu");
        int courseSelection= sc.nextInt();

            if (courseSelection == 2) {

            } else if (courseSelection == 1) {
                System.out.println("please select: ");
                metropolitanUniversityMU.listCoursesNames();
                AskForCourseInformationToSee(metropolitanUniversityMU);
            }

        } while(response!=0);
     }

     public void AskForNewCourse(MetropolitanUniversityMU metropolitanUniversityMU){
         System.out.println("Please see below the courses already exists with their classroom number: ");
         metropolitanUniversityMU.listCourseNamesAndClassroom();
         Scanner sc = new Scanner(System.in);
         System.out.println("---------------------------------------------------------------");
         System.out.println("Please enter the following data information for the new course:  ");
         System.out.println("Name of the new course");
         String nameNewCourse = sc.nextLine();
         System.out.println("Please insert name of classroom for the new course");
         int newClassroom = sc.nextInt();
         UITeacherMenu newTeacher = new UITeacherMenu();
         newTeacher.AskForTeacherInfo(metropolitanUniversityMU);
         System.out.println("do you want to continue assigning students? \n1. Yes \n2. No, take me to the main Menu ");
         int selection= sc.nextInt();
         if (selection == 2) {
               ArrayList<StudentMU>newList = new ArrayList<>();
                metropolitanUniversityMU.createNewCourse(nameNewCourse,newClassroom,metropolitanUniversityMU.getTeachersMU().get(metropolitanUniversityMU.getCoursesMU().size()),
                     newList);
         } else if (selection == 1) {
             ArrayList<StudentMU>newList = new ArrayList<>();
             metropolitanUniversityMU.createNewCourse(nameNewCourse,newClassroom,metropolitanUniversityMU.getTeachersMU().get(metropolitanUniversityMU.getCoursesMU().size()),
                     newList);
             UIStudentMenu newStudent = new UIStudentMenu();
             newStudent.askForStudent(metropolitanUniversityMU);
             metropolitanUniversityMU.addNewStudentToCourse(metropolitanUniversityMU.getStudentsMU().get(metropolitanUniversityMU.getStudentsMU().size()-1),
                                                    metropolitanUniversityMU.getCoursesMU().get(metropolitanUniversityMU.getCoursesMU().size()-1));

         }
     }

    }

